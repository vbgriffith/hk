/* FlyingScout — defined in Spitter.js */
