/* Projectile — defined in NPC.js */
