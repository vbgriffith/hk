/* ParticleSystem — defined in AudioSystem.js */
