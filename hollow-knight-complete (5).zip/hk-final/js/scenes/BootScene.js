/* js/scenes/BootScene.js — BootScene is defined in PreloadScene.js */
// BootScene and PreloadScene are both defined in PreloadScene.js
// This file is intentionally empty to avoid redeclaration.
'use strict';
