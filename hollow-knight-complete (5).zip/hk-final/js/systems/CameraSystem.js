/* CameraSystem — defined in AudioSystem.js */
