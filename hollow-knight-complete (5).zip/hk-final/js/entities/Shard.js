/* Shard — defined in NPC.js */
